@echo off
rem ============================================================
rem  Jiufeng Investment Workbench - one-click install entry
rem
rem  NOTE: keep this file PURE ASCII. All Chinese messages live in
rem  install.ps1, which is saved as UTF-8 with BOM and is therefore
rem  decoded correctly by PowerShell 5.1. cmd.exe would decode a
rem  UTF-8 .bat with the OEM codepage and garble anything non-ASCII.
rem
rem  install.ps1 lays down four layers:
rem    1) sidebar UI plugin
rem    2) finance data tools plugin (21 tools)
rem    3) AI agent preset (89 skills)
rem    4) app layer: icons / branding / update guard / prompt trimming
rem
rem  Layer 4 writes into the DSH install directory, so install.ps1
rem  raises its own "User Account Control" prompt for that step.
rem  There is NO need to right-click and run as administrator --
rem  just click "Yes" when the prompt shows up.
rem ============================================================

chcp 65001 >nul 2>&1
setlocal
cd /d "%~dp0"

set "SCRIPT=%~dp0install.ps1"

if not exist "%SCRIPT%" (
    echo.
    echo   [ERROR] install.ps1 not found next to this file.
    echo.
    echo   Please EXTRACT THE WHOLE ZIP ARCHIVE first, then run
    echo   this .bat file from inside the extracted folder.
    echo.
    echo   Do not copy this .bat file out on its own.
    echo.
    pause
    exit /b 1
)

echo.
echo   Installing Jiufeng Investment Workbench...
echo   Keep this window open; it takes a few minutes.
echo.
echo   Near the end a "User Account Control" prompt may appear.
echo   Click "Yes" to let it finish -- that is expected.
echo.

powershell -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT%" %*
set "RC=%ERRORLEVEL%"

if not "%RC%"=="0" (
    echo.
    echo   [ERROR] Installation failed, exit code %RC%.
    echo   Please read the messages above.
    echo.
    pause
)

endlocal
exit /b %RC%
