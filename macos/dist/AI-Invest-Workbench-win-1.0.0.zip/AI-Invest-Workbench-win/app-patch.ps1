﻿#Requires -Version 5.1
<#
  AI投研工作台 · app 包层补丁
  ================================================================
  这一步改的是 DSH Desktop 的安装目录（不是用户数据目录），所以要管理员权限。
  做四件事：
    1. 贴回应用图标（窗口图标 + 托盘图标）
    2. 品牌文案（托盘 tooltip / 窗口标题 / 首次设置向导 / 恢复助手 / 渲染页 HTML 标题）
    3. 受控更新守卫：禁用 DSH 自带更新入口
    4. prompt 收窄：关掉 DSH 的开发说明段（harness:source + app:web-surface）

  用法：
    powershell -NoProfile -ExecutionPolicy Bypass -File app-patch.ps1
    -DryRun    只看会改什么，不落盘
    -Verify    只校验当前状态
    -Revert    从备份还原品牌文案
    -NoLock    跳过更新守卫（保留官方更新入口）

  ----------------------------------------------------------------
  为什么会有这个脚本
  ----------------------------------------------------------------
  覆盖安装 DSH 会把 app 目录里的改动全部还原，所以每次基座升级后
  要重跑一次。集成在一键安装脚本里，粉丝装完即与作者环境一致。

  设计约束
  ----------------------------------------------------------------
  · 本文件必须存成「UTF-8 with BOM」（PS 5.1 否则按 GBK 解码中文）。
  · 不能用 && || ?? ?:。
  · 替换产品名只在「中文语境」里做 —— 这些 bundle 是单行压缩的，
    按字符串字面量无脑替换会打到代码标识符（data-dsh-boot 之类）上。
    判据：产品名紧邻中文字符才算文案。
#>

[CmdletBinding()]
param(
    [string]$AppRoot = '',
    [string]$Brand = 'AI投研工作台',
    [string]$PackageRoot = '',
    [switch]$DryRun = $false,
    [switch]$Verify = $false,
    [switch]$Revert = $false,
    [switch]$NoLock = $false,
    [switch]$Unattended = $false
)

$ErrorActionPreference = 'Stop'

try {
    $script:Utf8NoBom = New-Object System.Text.UTF8Encoding $false
    [Console]::OutputEncoding = $script:Utf8NoBom
    $OutputEncoding = $script:Utf8NoBom
}
catch {
    # 非交互宿主可能不允许改，忽略
}

# ================================================================
#  输出
# ================================================================

function Say-Ok   { param([string]$m) Write-Host ('  [OK]   ' + $m) -ForegroundColor Green }
function Say-Info { param([string]$m) Write-Host ('  ·      ' + $m) -ForegroundColor Gray }
function Say-Warn { param([string]$m) Write-Host ('  [警告] ' + $m) -ForegroundColor Yellow }
function Say-Err  { param([string]$m) Write-Host ('  [错误] ' + $m) -ForegroundColor Red }
function Say-Head { param([string]$m) Write-Host '' ; Write-Host ('  ── ' + $m + ' ' + ('─' * [Math]::Max(0, 52 - $m.Length))) -ForegroundColor Cyan }

# ================================================================
#  常量
# ================================================================

$OLD_PRODUCT = 'DSH Desktop'
$GUARD_TAG = 'GUARD:LOCKED'
$SLIM_TAG = 'GUARD:SLIM'
$UPDATE_ROW_ID = 'desktop-updates'
$SLIM_ROW_ID = 'web-runtime'
$SLIM_FIELD = 'surfaceContext'
$ICON_FILES = @('app-icon.png', 'tray-icon-blue.png', 'tray-icon-blue@2x.png')

# 中文语境字符类：只收中文特有的字符与全角标点。
# 不能包含 … — 这些通用标点 —— 英文里也在用，会把
# "Downloading DSH Desktop ${v}…" 这种英文串误判成中文语境。
$ZH_CLS = '[\u4e00-\u9fff\u201c\u201d\u2018\u2019\uff0c\u3002\u3001\uff1a\uff1b\uff01\uff1f\uff08\uff09\u3010\u3011\u300a\u300b]'

# 品牌文案目标文件（相对 app 目录的 glob）
$TARGETS = @(
    'lib/src-*.js',
    'lib/tray-locale-*.js',
    'lib/native-ui/assets/setup-wizard-*.js',
    'lib/native-ui/assets/recovery-copy-*.js',
    'node_modules/@deepseek-ai/dsh-web-frontend/dist/index.html'
)

$HTML_TITLE_OLD = '<title>DeepSeek Harness</title>'

# ================================================================
#  基础工具
# ================================================================

function Test-Admin {
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    $p = New-Object Security.Principal.WindowsPrincipal($id)
    return $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Resolve-AppRoot {
    <# 找 DSH 的 resources\app 目录 #>
    param([string]$Hint)

    $candidates = @()
    if ($Hint -ne '') { $candidates += $Hint }
    $candidates += @(
        (Join-Path $env:ProgramFiles 'DSH Desktop'),
        (Join-Path ${env:ProgramFiles(x86)} 'DSH Desktop'),
        (Join-Path $env:LOCALAPPDATA 'Programs\DSH Desktop'),
        (Join-Path $env:ProgramData 'DSH Desktop'),
        'D:\Program Files\DSH Desktop',
        'C:\DSH Desktop'
    )

    foreach ($dir in $candidates) {
        if ([string]::IsNullOrWhiteSpace($dir)) { continue }
        $app = Join-Path $dir 'resources\app'
        if (Test-Path -LiteralPath (Join-Path $app 'package.json')) {
            return $app
        }
    }
    return ''
}

function Read-TextFile {
    param([string]$Path)
    $raw = [System.IO.File]::ReadAllText($Path, [System.Text.Encoding]::UTF8)
    $hasBom = $raw.StartsWith([char]0xFEFF)
    if ($hasBom) { $raw = $raw.Substring(1) }
    return @{ Text = $raw; HasBom = $hasBom }
}

function Write-TextFile {
    param([string]$Path, [string]$Text, [bool]$HasBom)
    $enc = New-Object System.Text.UTF8Encoding $HasBom
    [System.IO.File]::WriteAllText($Path, $Text, $enc)
}

# ================================================================
#  1. 图标
# ================================================================

function Get-IconSourceDir {
    param([string]$PkgRoot)
    if ($PkgRoot -ne '' -and (Test-Path -LiteralPath (Join-Path $PkgRoot 'icons'))) {
        return (Join-Path $PkgRoot 'icons')
    }
    $here = Split-Path -Parent $MyInvocation.MyCommand.Path
    if (Test-Path -LiteralPath (Join-Path $here 'icons')) {
        return (Join-Path $here 'icons')
    }
    return ''
}

function Sync-Icons {
    param([string]$App, [string]$SrcDir, [bool]$Write)

    $build = Join-Path $App 'build'
    if (-not (Test-Path -LiteralPath $build)) {
        Say-Warn ('找不到图标目标目录：' + $build)
        return 0
    }

    $n = 0
    foreach ($f in $ICON_FILES) {
        $src = Join-Path $SrcDir $f
        $dst = Join-Path $build $f

        if (-not (Test-Path -LiteralPath $src)) {
            Say-Warn ('包内缺少图标：' + $f)
            continue
        }

        $same = $false
        if (Test-Path -LiteralPath $dst) {
            $h1 = (Get-FileHash -LiteralPath $src -Algorithm SHA256).Hash
            $h2 = (Get-FileHash -LiteralPath $dst -Algorithm SHA256).Hash
            $same = ($h1 -eq $h2)
        }

        if ($same) {
            Say-Info ($f + '  已是最新')
            continue
        }

        if ($Write) {
            Copy-Item -LiteralPath $src -Destination $dst -Force
            Say-Ok ($f + '  已贴回')
        }
        else {
            Say-Info ('[预演] 会覆盖 ' + $f)
        }
        $n++
    }
    return $n
}

# ================================================================
#  2. 品牌文案
# ================================================================

function Get-BrandChanges {
    <#
        对一段文本应用品牌替换规则。
        返回 @{ Text; Changes }，Changes 是 @{ Old; New; Why } 数组。
    #>
    param([string]$Text, [string]$Rel)

    $changes = @()

    # HTML：静态标题整串替换（任务栏 / Alt+Tab 从一开始就是品牌名）
    if ($Rel.EndsWith('.html')) {
        if ($Text.Contains($HTML_TITLE_OLD)) {
            $new = '<title>' + $Brand + '</title>'
            $Text = $Text.Replace($HTML_TITLE_OLD, $new)
            $changes += @{ Old = $HTML_TITLE_OLD; New = $new; Why = 'HTML 标题' }
        }
        return @{ Text = $Text; Changes = $changes }
    }

    # 精确替换只对 lib/src-*.js：这两个是代码标识符，不走中文语境规则
    if ($Rel.StartsWith('lib/src-')) {
        $exact = @(
            @{ Old = 'productName: DESKTOP_PRODUCT_NAME,'; New = ('productName: "' + $Brand + '",'); Expect = 1 },
            @{ Old = 'windowTitle: "DeepSeek Harness Desktop",'; New = ('windowTitle: "' + $Brand + '",'); Expect = 1 }
        )
        foreach ($e in $exact) {
            $c = ([regex]::Matches($Text, [regex]::Escape($e.Old))).Count
            if ($c -eq 0) { continue }
            if ($c -ne $e.Expect) {
                Say-Warn ($Rel + '：' + $e.Old + ' 命中 ' + $c + ' 次（预期 ' + $e.Expect + '），跳过')
                continue
            }
            $Text = $Text.Replace($e.Old, $e.New)
            $changes += @{ Old = $e.Old; New = $e.New; Why = '代码标识符' }
        }
    }

    # 中文语境替换。长词在前：先处理 "DSH Desktop"，剩下的 "DSH " 再单独处理。
    $rules = @(
        @{ Pat = ('(' + $ZH_CLS + '\s*)' + [regex]::Escape($OLD_PRODUCT)); New = $Brand; Keep = $true },
        @{ Pat = ([regex]::Escape($OLD_PRODUCT) + '(?=\s*(?:\$\{[^}]*\}\s*)?' + $ZH_CLS + ')'); New = $Brand; Keep = $false },
        @{ Pat = ('(' + $ZH_CLS + '\s*)DSH '); New = 'AI投研'; Keep = $true },
        @{ Pat = ('DSH (?=\s*(?:\$\{[^}]*\}\s*)?' + $ZH_CLS + ')'); New = 'AI投研'; Keep = $false }
    )

    foreach ($r in $rules) {
        $rx = New-Object System.Text.RegularExpressions.Regex($r.Pat)
        $matches = $rx.Matches($Text)
        if ($matches.Count -eq 0) { continue }

        foreach ($m in $matches) {
            $ctx = $Text.Substring([Math]::Max(0, $m.Index - 12), [Math]::Min(12, $m.Index))
            $ctxAfter = $Text.Substring($m.Index + $m.Length, [Math]::Min(12, $Text.Length - $m.Index - $m.Length))
            $changes += @{ Old = ($ctx + $m.Value + $ctxAfter); New = ''; Why = '中文文案' }
        }

        $evaluator = {
            param($m)
            if ($r.Keep) { return $m.Groups[1].Value + $r.New }
            return $r.New
        }
        $Text = $rx.Replace($Text, $evaluator)
    }

    return @{ Text = $Text; Changes = $changes }
}

function Get-BrandTargets {
    param([string]$App)

    $out = @()
    foreach ($pat in $TARGETS) {
        $full = Join-Path $App $pat
        $dir = Split-Path -Parent $full
        $leaf = Split-Path -Leaf $full
        if (-not (Test-Path -LiteralPath $dir)) { continue }
        Get-ChildItem -LiteralPath $dir -Filter $leaf -File -ErrorAction SilentlyContinue |
            Where-Object { -not $_.Name.EndsWith('.map') } |
            Sort-Object Name |
            ForEach-Object { $out += $_ }
    }
    return $out
}

function Invoke-BrandPatch {
    param([string]$App, [bool]$Write)

    $files = Get-BrandTargets -App $App
    if ($files.Count -eq 0) {
        Say-Warn '没有找到任何品牌文案目标文件（DSH 版本可能变了）'
        return @{ Changed = 0; Skipped = 0 }
    }

    $total = 0
    $skipped = 0

    foreach ($f in $files) {
        $rel = $f.FullName.Substring($App.Length).TrimStart('\').Replace('\', '/')
        $info = Read-TextFile -Path $f.FullName
        $res = Get-BrandChanges -Text $info.Text -Rel $rel

        $real = @($res.Changes | Where-Object { $_.Why -ne '★' })
        if ($real.Count -eq 0) {
            Say-Info ($rel + '  已无待替换')
            $skipped++
            continue
        }

        if ($Write) {
            Write-TextFile -Path $f.FullName -Text $res.Text -HasBom $info.HasBom
            Say-Ok ($rel + '  替换 ' + $real.Count + ' 处')
        }
        else {
            Say-Info ('[预演] ' + $rel + '  会替换 ' + $real.Count + ' 处')
        }
        $total += $real.Count
    }

    return @{ Changed = $total; Skipped = $skipped }
}

function Backup-BrandFiles {
    param([string]$App, [string[]]$Paths)

    $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    $dir = Join-Path (Split-Path -Parent $PSCommandPath) ('app-brand-backup-' + $stamp)
    New-Item -ItemType Directory -Path $dir -Force | Out-Null

    $map = @()
    foreach ($p in $Paths) {
        $rel = $p.Substring($App.Length).TrimStart('\').Replace('\', '/')
        $flat = $rel.Replace('/', '__')
        Copy-Item -LiteralPath $p -Destination (Join-Path $dir $flat) -Force
        $map += ($flat + '=' + $rel)
    }
    Write-TextFile -Path (Join-Path $dir 'map.txt') -Text ($map -join "`r`n") -HasBom $false
    return $dir
}

function Invoke-BrandRevert {
    param([string]$App)

    $here = Split-Path -Parent $PSCommandPath
    $bks = @(Get-ChildItem -LiteralPath $here -Directory -Filter 'app-brand-backup-*' -ErrorAction SilentlyContinue | Sort-Object Name)
    if ($bks.Count -eq 0) {
        Say-Err '没有找到品牌文案备份，无法还原'
        return 1
    }
    $dir = $bks[$bks.Count - 1]
    $mapPath = Join-Path $dir.FullName 'map.txt'
    if (-not (Test-Path -LiteralPath $mapPath)) {
        Say-Err '备份缺少 map.txt，无法还原'
        return 1
    }

    $n = 0
    foreach ($line in [System.IO.File]::ReadAllLines($mapPath)) {
        if ($line.Trim() -eq '') { continue }
        $parts = $line.Split('=')
        $flat = $parts[0]
        $rel = $parts[1]
        $src = Join-Path $dir.FullName $flat
        $dst = Join-Path $App $rel.Replace('/', '\')
        if (Test-Path -LiteralPath $src) {
            Copy-Item -LiteralPath $src -Destination $dst -Force
            Say-Ok ('还原 ' + $rel)
            $n++
        }
    }
    Say-Info ('备份目录：' + $dir.Name)
    return 0
}

# ================================================================
#  3 & 4. app 层 cordis.patch.yml：更新锁 + prompt 收窄
# ================================================================

function Find-PatchRow {
    <#
        在 patch 文件的行数组里定位指定 id 的条目。
        返回 @{ RowIndex; DisabledIndex; Indent; ConfigField(表名->行号) }
        找不到返回 $null。
    #>
    param([string[]]$Lines, [string]$Id)

    $rowIndex = -1
    for ($i = 0; $i -lt $Lines.Count; $i++) {
        if ($Lines[$i] -match ('^\s*-\s*id:\s*' + [regex]::Escape($Id) + '\s*$')) { $rowIndex = $i; break }
    }
    if ($rowIndex -lt 0) { return $null }

    $indent = ([regex]::Match($Lines[$rowIndex], '^\s*')).Value
    $disabledIndex = -1
    $fields = @{}

    for ($j = $rowIndex + 1; $j -lt $Lines.Count; $j++) {
        $line = $Lines[$j]
        if ($line -match '^\s*-\s*id:') { break }
        if ($line -match '^\s*-\s') { break }
        if ($line -match '^\s*disabled:\s') { $disabledIndex = $j }
        $fm = [regex]::Match($line, '^\s{2,}([A-Za-z_][\w]*):\s')
        if ($fm.Success -and -not $fields.ContainsKey($fm.Groups[1].Value)) {
            $fields[$fm.Groups[1].Value] = $j
        }
    }

    return @{
        RowIndex      = $rowIndex
        DisabledIndex = $disabledIndex
        Indent        = $indent
        Fields        = $fields
    }
}

function Ensure-RowDisabled {
    param([string[]]$Lines, [string]$Id, [string]$Tag)

    $row = Find-PatchRow -Lines $Lines -Id $Id
    if ($null -eq $row) {
        return @{ Lines = $Lines; State = 'notfound' }
    }

    if ($row.DisabledIndex -ge 0) {
        $line = $Lines[$row.DisabledIndex]
        if ($line -match 'disabled:\s*(true|!!js\s+true)') {
            return @{ Lines = $Lines; State = 'already' }
        }
        $Lines[$row.DisabledIndex] = ($row.Indent + 'disabled: true   # ' + $Tag)
        return @{ Lines = $Lines; State = 'fixed' }
    }

    # 没有 disabled 字段：插在 name 行之后
    $insertAt = $row.RowIndex + 1
    $newLines = @()
    $newLines += $Lines[0..($insertAt - 1)]
    $newLines += ($row.Indent + 'disabled: true   # ' + $Tag)
    if ($insertAt -lt $Lines.Count) {
        $newLines += $Lines[$insertAt..($Lines.Count - 1)]
    }
    return @{ Lines = $newLines; State = 'inserted' }
}

function Ensure-ConfigField {
    <#
        确保某一行（含 config: 段）里的某个标量字段是期望值。
        例：web-runtime 的 surfaceContext 要等于 false。
    #>
    param([string[]]$Lines, [string]$Id, [string]$Field, [string]$Value, [string]$Tag)

    $row = Find-PatchRow -Lines $Lines -Id $Id
    if ($null -eq $row) {
        return @{ Lines = $Lines; State = 'notfound' }
    }

    if ($row.Fields.ContainsKey($Field)) {
        $idx = $row.Fields[$Field]
        $line = $Lines[$idx]
        if ($line -match ('^\s*' + [regex]::Escape($Field) + ':\s*' + [regex]::Escape($Value) + '\s*(#.*)?$')) {
            return @{ Lines = $Lines; State = 'already' }
        }
        $lead = ([regex]::Match($line, '^\s*')).Value
        $Lines[$idx] = ($lead + $Field + ': ' + $Value + '   # ' + $Tag)
        return @{ Lines = $Lines; State = 'fixed' }
    }

    # 字段不存在：插到该条目末尾
    $end = $Lines.Count
    for ($j = $row.RowIndex + 1; $j -lt $Lines.Count; $j++) {
        if ($Lines[$j] -match '^\s*-\s*id:') { $end = $j; break }
        if ($Lines[$j] -match '^\s*-\s') { $end = $j; break }
    }
    $lead = $row.Indent + '  '
    # 若该条目已有 config: 行，缩进要再深一层
    foreach ($k in $row.Fields.Keys) {
        if ($k -eq 'config') {
            $cfgLine = $Lines[$row.Fields[$k]]
            $lead = ([regex]::Match($cfgLine, '^\s*')).Value + '  '
        }
    }
    $newLines = @()
    if ($end -gt 0) { $newLines += $Lines[0..($end - 1)] }
    $newLines += ($lead + $Field + ': ' + $Value + '   # ' + $Tag)
    if ($end -lt $Lines.Count) { $newLines += $Lines[$end..($Lines.Count - 1)] }
    return @{ Lines = $newLines; State = 'inserted' }
}

function Invoke-AppPatchFile {
    param([string]$App, [bool]$Write, [bool]$Lock)

    $path = Join-Path $App 'cordis.patch.yml'
    if (-not (Test-Path -LiteralPath $path)) {
        Say-Warn ('找不到 app 层 patch 文件：' + $path)
        return @{ Update = 'missing'; Slim = 'missing' }
    }

    $ls = [System.IO.File]::ReadAllLines($path)
    $orig = $ls -join "`n"

    $rUpdate = 'skipped'
    if (-not $Lock) {
        $say = Say-Info '按 -NoLock 跳过更新守卫'
    }
    else {
        $res = Ensure-RowDisabled -Lines $ls -Id $UPDATE_ROW_ID -Tag "$GUARD_TAG 受控更新守卫"
        $ls = $res.Lines
        $rUpdate = $res.State
    }

    $res2 = Ensure-ConfigField -Lines $ls -Id $SLIM_ROW_ID -Field $SLIM_FIELD -Value 'false' -Tag "$SLIM_TAG 关闭 DSH 开发说明段"
    $ls = $res2.Lines
    $rSlim = $res2.State

    $new = $ls -join "`n"
    if ($new -eq $orig) {
        Say-Info 'app 层 patch 无需改动'
    }
    elseif ($Write) {
        Copy-Item -LiteralPath $path -Destination ($path + '.bak-jiufeng-' + (Get-Date -Format 'yyyyMMdd-HHmmss')) -Force
        Write-TextFile -Path $path -Text ($new + "`n") -HasBom $false
        Say-Ok ('已更新 app 层 patch（更新守卫=' + $rUpdate + '，prompt 收窄=' + $rSlim + '）')
    }
    else {
        Say-Info ('[预演] 会更新 app 层 patch（更新守卫=' + $rUpdate + '，prompt 收窄=' + $rSlim + '）')
    }

    return @{ Update = $rUpdate; Slim = $rSlim }
}

# ================================================================
#  主流程
# ================================================================

Write-Host ''
Write-Host '  AI投研工作台 · app 包层补丁' -ForegroundColor White
Write-Host ('  ' + ('─' * 58)) -ForegroundColor DarkGray

$app = Resolve-AppRoot -Hint $AppRoot
if ($app -eq '') {
    Say-Err '没有找到 DSH Desktop 的 resources\app 目录'
    Say-Info '如果你的 DSH 装在非标准位置，请手动指定：'
    Write-Host '          app-patch.ps1 -AppRoot "D:\你的路径\DSH Desktop"' -ForegroundColor DarkCyan
    exit 1
}
Say-Info ('DSH app 目录：' + $app)

if ($Revert) {
    $rc = Invoke-BrandRevert -App $app
    exit $rc
}

if ($Verify) {
    $files = Get-BrandTargets -App $app
    $bad = 0
    Say-Head '品牌文案校验'
    foreach ($f in $files) {
        $rel = $f.FullName.Substring($app.Length).TrimStart('\').Replace('\', '/')
        $info = Read-TextFile -Path $f.FullName
        $res = Get-BrandChanges -Text $info.Text -Rel $rel
        if ($res.Changes.Count -gt 0) {
            Say-Warn ($rel + '  仍有 ' + $res.Changes.Count + ' 处未替换')
            $bad++
        }
        else {
            Say-Ok ($rel + '  已是品牌文案')
        }
    }

    Say-Head '图标'
    $srcDir = Get-IconSourceDir -PkgRoot $PackageRoot
    if ($srcDir -ne '') {
        [void](Sync-Icons -App $app -SrcDir $srcDir -Write $false)
    }

    Say-Head '更新守卫'
    $ls = [System.IO.File]::ReadAllLines((Join-Path $app 'cordis.patch.yml'))
    $row = Find-PatchRow -Lines $ls -Id $UPDATE_ROW_ID
    if ($null -eq $row) {
        Say-Warn '没找到 desktop-updates 条目'
    }
    elseif ($row.DisabledIndex -ge 0 -and $ls[$row.DisabledIndex] -match 'disabled:\s*(true|!!js\s+true)') {
        Say-Ok '更新入口已锁定'
    }
    else {
        Say-Warn '更新入口未锁定'
    }

    if ($bad -gt 0) { exit 1 }
    exit 0
}

$isAdmin = Test-Admin
if (-not $isAdmin -and -not $DryRun) {
    Say-Err '这一步要写 DSH 安装目录，需要管理员权限'
    Say-Info '请右键「以管理员身份运行」install.bat，或单独以管理员身份跑这个脚本'
    exit 3
}

if (-not $isAdmin) {
    Say-Warn '[预演] 当前不是管理员，真实运行会需要提权'
}

# 1. 图标
Say-Head '应用图标'
$srcDir = Get-IconSourceDir -PkgRoot $PackageRoot
if ($srcDir -eq '') {
    Say-Warn '包内没有 icons 目录，跳过'
}
else {
    [void](Sync-Icons -App $app -SrcDir $srcDir -Write (-not $DryRun))
}

# 2. 品牌文案
Say-Head '品牌文案'
$files = Get-BrandTargets -App $app
$needWrite = @()
foreach ($f in $files) {
    $rel = $f.FullName.Substring($app.Length).TrimStart('\').Replace('\', '/')
    $info = Read-TextFile -Path $f.FullName
    $res = Get-BrandChanges -Text $info.Text -Rel $rel
    if ($res.Changes.Count -gt 0) { $needWrite += $f.FullName }
}

if ($needWrite.Count -gt 0 -and -not $DryRun) {
    $bdir = Backup-BrandFiles -App $app -Paths $needWrite
    Say-Info ('已备份原文件 -> ' + (Split-Path $bdir -Leaf))
}
$r = Invoke-BrandPatch -App $app -Write (-not $DryRun)
Say-Info ('合计替换 ' + $r.Changed + ' 处')

# 3 & 4. 更新锁 + prompt 收窄
Say-Head '更新守卫与 prompt 收窄'
[void](Invoke-AppPatchFile -App $app -Write (-not $DryRun) -Lock (-not $NoLock))

Write-Host ''
if ($DryRun) {
    Write-Host '  预演结束，没有改动任何文件。' -ForegroundColor Yellow
}
else {
    Write-Host '  app 包层补丁完成。' -ForegroundColor Green
    Write-Host '  注意：DSH 覆盖安装会还原这些改动，升级后重跑本脚本即可。' -ForegroundColor DarkGray
}
Write-Host ''

# 被 install.ps1 用 RunAs 提权拉起时，这里是另开的一个窗口。
# 不暂停的话，窗口会在粉丝看清结果之前就关掉。
# install.ps1 共用同一个控制台调用时会传 -Unattended，避免出现两次「按回车」。
if (-not $Unattended) {
    Write-Host '  按回车键关闭此窗口' -ForegroundColor DarkGray
    $null = Read-Host
}

exit 0
