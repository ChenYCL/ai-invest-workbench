﻿#Requires -Version 5.1
<#
  AI投研工作台 · 一键安装脚本
  ================================================================
  目标：装完之后，粉丝的 DSH 和作者本地环境完全一致。

  这个脚本做九件事（分三层）：
    1. 检测 DSH Desktop 是否已安装（没有就调用同目录的官方安装包）
    2. 确认 DSH 已经初始化过（全新安装的 DSH 需要先跑一次才有 profile 目录）
    3. 把两个插件复制到 %USERPROFILE%\.dsh\jiufeng-plugins\，
       改写 profile 的 package.json，并在 node_modules 下挂上目录链接
    4. 安装投研 Agent 预设（89 个技能）到 %USERPROFILE%\.dsh\.agent-presets\
    5. 把默认 Agent 预设设成 ai-finance
    6. 铺品牌图标到 %USERPROFILE%\.dsh\icons\
    7. 写 profile 层的 cordis.patch.yml（停用与投研无关的 host 插件）
    8. app 包层：贴回应用图标
    9. app 包层：品牌文案 + 受控更新守卫 + prompt 收窄

  其中 8、9 两步要写 DSH 安装目录，需要管理员权限；
  没有权限时会跳到提权重跑，或者提示粉丝手动处理。

  用法：
    powershell -NoProfile -ExecutionPolicy Bypass -File install.ps1
    加 -DryRun     可以只看会做什么、不真的改任何东西
    加 -Unattended 不交互（给自动化用）
    加 -SkipApp    跳过需要管理员权限的 8、9 两步

  ----------------------------------------------------------------
  设计约束（都是踩过的坑，改之前先看这条）
  ----------------------------------------------------------------
  · 本文件必须存成「UTF-8 with BOM」。
    PowerShell 5.1 读取无 BOM 的 UTF-8 时会按 GBK(ANSI) 解码，
    中文全部变乱码，然后报一堆看似无关的语法错误。

  · 改写 profile\package.json 时必须写出「无 BOM 的 UTF-8」。
    和上一条正好相反 —— 带 BOM 会让 Node 的 JSON.parse 直接抛异常，
    DSH 就起不来了。settings.yaml 则要保留它原本的 BOM 状态。

  · 不能用 && || ?? ?:，PowerShell 5.1 不支持这些语法。

  · 目录链接用 junction，不用 symlink。
    symlink 需要开发者模式或管理员权限，junction 不需要。

  · 改文件一律"读原文 → 只替换目标片段 → 按原换行符写回"，
    不要用 ConvertFrom-Json / ConvertFrom-Yaml 整份重排 ——
    那会把 DSH 自己维护的格式和注释全部冲掉。
#>

[CmdletBinding()]
param(
    [string]$ProfileName = '',
    [switch]$DryRun = $false,
    [switch]$Unattended = $false,
    [switch]$SkipApp = $false
)

$ErrorActionPreference = 'Stop'

# 锁定控制台输出编码为 UTF-8。
# 少了这一步，在 chcp 65001 的 cmd 里跑时，Write-Host 仍可能按 OEM 代码页
# 编码输出，中文会变成「鐜栧嘲」这种乱码。install.bat 已经先 chcp 65001 了，
# 这里再把 PowerShell 侧的编码对齐。
try {
    $script:Utf8NoBom = New-Object System.Text.UTF8Encoding $false
    [Console]::OutputEncoding = $script:Utf8NoBom
    $OutputEncoding = $script:Utf8NoBom
}
catch {
    # 某些宿主（比如 ISE）不允许改，忽略即可
}

# ================================================================
#  输出
# ================================================================

$script:StepNo = 0
$script:StepTotal = 9

function Say-Banner {
    Write-Host ''
    Write-Host '  ============================================' -ForegroundColor DarkCyan
    Write-Host '       AI投研工作台 · 一键安装' -ForegroundColor Cyan
    Write-Host '       让投研工作更简单' -ForegroundColor DarkGray
    Write-Host '  ============================================' -ForegroundColor DarkCyan
    if ($DryRun) {
        Write-Host ''
        Write-Host '  [预演模式] 只显示会做什么，不会真的改动任何文件' -ForegroundColor Yellow
    }
    Write-Host ''
}

function Say-Step {
    param([string]$Text)
    $script:StepNo++
    Write-Host ''
    Write-Host ("  [" + $script:StepNo + "/" + $script:StepTotal + "] " + $Text) -ForegroundColor Cyan
}

function Say-Ok {
    param([string]$Text)
    Write-Host ("        OK  " + $Text) -ForegroundColor Green
}

function Say-Info {
    param([string]$Text)
    Write-Host ("        ..  " + $Text) -ForegroundColor Gray
}

function Say-Warn {
    param([string]$Text)
    Write-Host ("        !!  " + $Text) -ForegroundColor Yellow
}

function Say-Err {
    param([string]$Text)
    Write-Host ("        XX  " + $Text) -ForegroundColor Red
}

function Pause-Exit {
    param([int]$Code = 0)
    Write-Host ''
    if ($Unattended) {
        exit $Code
    }
    if ($Code -eq 0) {
        Write-Host '  按回车键关闭此窗口' -ForegroundColor DarkGray
    }
    else {
        Write-Host '  出错了。按回车键关闭此窗口' -ForegroundColor DarkGray
    }
    $null = Read-Host
    exit $Code
}

# ================================================================
#  资源定位
# ================================================================

$script:PluginNames = @('dsh-ai-invest-sidebar', 'dsh-finance-tools')
$script:DshExeName = 'DSH Desktop.exe'

# ── 投研 Agent 预设（89 个技能）────────────────────────────────────
# 只放插件是不够的：插件提供"侧边栏 UI + 21 个数据工具"，
# 而真正的投研技能体系（含多空辩论）挂在 agent preset 里。
# 不装它，粉丝的默认 Agent 仍是标准编码 Agent，人设与界面不匹配。
$script:PresetId = 'ai-finance'
$script:PresetDirName = 'ai-finance'

# ── profile 层要停用的插件行（与作者本机环境一致）──────────────────
# 这些与投研工作流无关：遥测、消息反馈、/feedback 命令、
# 「Open In...」按钮的 host 与浏览器两半、PTC 专用运行时。
#
# Note 是写给粉丝看的说明注释，会一并写进 cordis.patch.yml ——
# 作者本机那份也是带注释的，保持一致，顺便让粉丝知道怎么恢复。
$script:SlimEntries = @(
    @{
        Id   = 'session-telemetry-otel'
        Note = @(
            '遥测（OTel）。上游注释：mode=FEEDBACK_ONLY 时只有用户显式反馈才会上报；',
            '要彻底关掉，官方开关是 DSH_TELEMETRY_DISABLED 环境变量，config 无法禁行。'
        )
    },
    @{
        Id   = 'message-feedback'
        Note = @('消息反馈（气泡上的赞/踩 + 反馈浮层）')
    },
    @{
        Id   = 'command-feedback'
        Note = @('/feedback 斜杠命令')
    },
    @{
        Id   = 'open-in-app'
        Note = @('会话头部「Open In...」按钮的 host 半边（应用解析 + 拉活）')
    },
    @{
        Id   = 'ui-open-in-app'
        Note = @('同一个按钮的浏览器半边')
    },
    @{
        Id   = 'code-runtime'
        Note = @('PTC（programmatic tool calling）专用运行时；DSH_TOOLS_MODE 未设时用不到')
    }
)

# 只是 id 列表，给 DryRun 提示用
$script:SlimIds = @($script:SlimEntries | ForEach-Object { $_.Id })

# ── app 包层要贴回的文件 ──────────────────────────────────────────
# 图标文件名与目标子目录（DSH 安装目录下的 resources\app\build）
$script:IconFiles = @('app-icon.png', 'tray-icon-blue.png', 'tray-icon-blue@2x.png')
$script:AppBuildSub = 'resources\app\build'
$script:AppPatchYml = 'resources\app\cordis.patch.yml'

# ── 用户数据层要铺的图标（~\.dsh\icons）───────────────────────────
# 比 app 包层多三个：.ico 给快捷方式与任务栏用，logo-transparent.png 备用。
# 这一层写在用户目录下，不需要管理员权限。
$script:UserIconFiles = @(
    'app-icon.png',
    'app-icon.ico',
    'dsh.ico',
    'logo-transparent.png',
    'tray-icon-blue.png',
    'tray-icon-blue@2x.png'
)

function Get-PackageRoot {
    # 脚本所在目录即安装包根目录
    return $PSScriptRoot
}

function Test-PackageComplete {
    param([string]$Root)

    $missing = @()
    $pluginsDir = Join-Path $Root 'plugins'
    foreach ($n in $script:PluginNames) {
        $p = Join-Path $pluginsDir $n
        if (-not (Test-Path -LiteralPath $p)) {
            $missing += ('plugins\' + $n)
        }
        else {
            $manifest = Join-Path $p 'package.json'
            if (-not (Test-Path -LiteralPath $manifest)) {
                $missing += ('plugins\' + $n + '\package.json')
            }
        }
    }

    # 投研 Agent 预设：没有它就没有 89 个技能和多空辩论，人设也对不上
    $presetDir = Join-Path (Join-Path $Root 'agent-preset') $script:PresetDirName
    if (-not (Test-Path -LiteralPath $presetDir)) {
        $missing += ('agent-preset\' + $script:PresetDirName)
    }
    else {
        if (-not (Test-Path -LiteralPath (Join-Path $presetDir 'preset.yml'))) {
            $missing += ('agent-preset\' + $script:PresetDirName + '\preset.yml')
        }
        $skillCount = @(Get-ChildItem -LiteralPath (Join-Path $presetDir 'skills') -Directory -ErrorAction SilentlyContinue).Count
        if ($skillCount -lt 80) {
            $missing += ('agent-preset\' + $script:PresetDirName + '\skills（只有 ' + $skillCount + ' 个技能）')
        }
    }

    # 品牌图标（用户数据层用全套 6 个，是 app 包层 3 个的超集）
    $iconsDir = Join-Path $Root 'icons'
    foreach ($n in $script:UserIconFiles) {
        if (-not (Test-Path -LiteralPath (Join-Path $iconsDir $n))) {
            $missing += ('icons\' + $n)
        }
    }

    return $missing
}

# ================================================================
#  DSH 探测
# ================================================================

function Find-DshInstall {
    <# 返回 DSH Desktop 的安装目录（找不到返回空字符串） #>

    $found = New-Object System.Collections.ArrayList

    # 1) 常见安装位置
    $candidates = New-Object System.Collections.ArrayList
    if ($env:ProgramFiles) {
        [void]$candidates.Add((Join-Path $env:ProgramFiles 'DSH Desktop'))
    }
    $pf86 = [Environment]::GetEnvironmentVariable('ProgramFiles(x86)')
    if ($pf86) {
        [void]$candidates.Add((Join-Path $pf86 'DSH Desktop'))
    }
    if ($env:LOCALAPPDATA) {
        [void]$candidates.Add((Join-Path $env:LOCALAPPDATA 'Programs\DSH Desktop'))
    }
    if ($env:ProgramData) {
        [void]$candidates.Add((Join-Path $env:ProgramData 'DSH Desktop'))
    }
    [void]$candidates.Add('D:\Program Files\DSH Desktop')
    [void]$candidates.Add('C:\DSH Desktop')

    foreach ($dir in $candidates) {
        $exe = Join-Path $dir $script:DshExeName
        if (Test-Path -LiteralPath $exe) {
            [void]$found.Add($dir)
        }
    }

    if ($found.Count -gt 0) {
        return $found[0]
    }

    # 2) 卸载注册表里找（覆盖自定义安装路径）
    $uninstallRoots = @(
        'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*',
        'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*',
        'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*'
    )
    foreach ($r in $uninstallRoots) {
        $apps = Get-ItemProperty -Path $r -ErrorAction SilentlyContinue |
            Where-Object { $_.DisplayName -like '*DSH Desktop*' }
        foreach ($a in $apps) {
            if ($a.InstallLocation) {
                $exe = Join-Path $a.InstallLocation $script:DshExeName
                if (Test-Path -LiteralPath $exe) {
                    return $a.InstallLocation
                }
            }
        }
    }

    return ''
}

function Get-DshProcess {
    return @(Get-Process -Name 'DSH Desktop' -ErrorAction SilentlyContinue)
}

function Wait-DshClosed {
    <# 改 profile 前必须确保 DSH 没在跑，否则它退出时会把改动盖回去 #>

    $procs = Get-DshProcess
    if ($procs.Count -eq 0) {
        Say-Ok 'DSH Desktop 当前未运行，可以安全修改配置'
        return $true
    }

    Say-Warn ('检测到 DSH Desktop 正在运行（' + $procs.Count + ' 个进程）')
    Say-Info '修改配置前必须先退出它，否则改动会被覆盖'

    $ans = 'y'
    if (-not $Unattended) {
        Write-Host ''
        $ans = Read-Host '  要现在自动关闭它吗？输入 y 自动关闭，输入 n 我自己手动关 (y/n)'
    }
    else {
        Say-Info '[无人值守] 自动关闭 DSH Desktop'
    }

    if ($ans -eq 'y' -or $ans -eq 'Y') {
        foreach ($p in $procs) {
            try {
                $p.CloseMainWindow() | Out-Null
            }
            catch {
            }
        }
        Start-Sleep -Seconds 3
        foreach ($p in (Get-DshProcess)) {
            try {
                Stop-Process -Id $p.Id -Force -ErrorAction SilentlyContinue
            }
            catch {
            }
        }
        Start-Sleep -Seconds 2
    }
    else {
        Say-Info '请手动完全退出 DSH Desktop（包括托盘图标）'
        if (-not $Unattended) {
            $null = Read-Host '  退出后按回车继续'
        }
    }

    if ((Get-DshProcess).Count -gt 0) {
        Say-Err 'DSH Desktop 仍在运行，无法继续'
        Say-Info '请在任务管理器里结束所有 "DSH Desktop" 进程后重新运行本脚本'
        return $false
    }

    Say-Ok 'DSH Desktop 已关闭'
    return $true
}

# ================================================================
#  profile 定位与初始化
# ================================================================

function Get-DshHome {
    if ($env:DSH_HOME) {
        return $env:DSH_HOME
    }
    return (Join-Path $env:USERPROFILE '.dsh')
}

function Start-DshToInitialize {
    <# 全新安装的 DSH 还没建 profile 目录，需要跑一次让它自己初始化 #>

    $exePath = Join-Path (Find-DshInstall) $script:DshExeName
    $dshHome = Get-DshHome
    $profilesDir = Join-Path $dshHome 'profiles'

    Say-Warn 'DSH Desktop 还没有初始化过（找不到 profile 目录）'
    Say-Info '接下来会启动一次 DSH Desktop，让它自动建好配置，然后本脚本会关掉它'
    Say-Info '如果弹出登录或向导窗口，不用管它，等一会儿就好'
    if (-not $Unattended) {
        Write-Host ''
        $null = Read-Host '  按回车开始初始化'
    }

    if ($DryRun) {
        Say-Info '[预演] 会启动 DSH Desktop 并等待 profile 目录出现'
        return ''
    }

    try {
        Start-Process -FilePath $exePath | Out-Null
    }
    catch {
        Say-Err ('启动失败：' + $_.Exception.Message)
        return ''
    }

    # 等 profile 目录出现，最多 120 秒
    $deadline = (Get-Date).AddSeconds(120)
    $dot = 0
    while ((Get-Date) -lt $deadline) {
        if (Test-Path -LiteralPath $profilesDir) {
            $subs = @(Get-ChildItem -LiteralPath $profilesDir -Directory -ErrorAction SilentlyContinue)
            if ($subs.Count -gt 0) {
                break
            }
        }
        Start-Sleep -Seconds 2
        $dot++
        if ($dot % 5 -eq 0) {
            Write-Host '        ..  等待初始化...' -ForegroundColor DarkGray
        }
    }

    if (-not (Test-Path -LiteralPath $profilesDir)) {
        Say-Err '等了 120 秒还没看到 profile 目录'
        Say-Info '请手动打开一次 DSH Desktop，确认它能正常启动并进入主界面，'
        Say-Info '然后关掉它，再重新运行本脚本。'
        return ''
    }

    # 关掉它
    Start-Sleep -Seconds 2
    foreach ($p in (Get-DshProcess)) {
        try {
            $p.CloseMainWindow() | Out-Null
        }
        catch {
        }
    }
    Start-Sleep -Seconds 3
    foreach ($p in (Get-DshProcess)) {
        try {
            Stop-Process -Id $p.Id -Force -ErrorAction SilentlyContinue
        }
        catch {
        }
    }
    Start-Sleep -Seconds 2

    Say-Ok '初始化完成，DSH Desktop 已关闭'
    return $profilesDir
}

function Resolve-ProfileDir {
    <# 返回要写入的 profile 目录全路径 #>

    $dshHome = Get-DshHome
    $profilesDir = Join-Path $dshHome 'profiles'

    if (-not (Test-Path -LiteralPath $profilesDir)) {
        $r = Start-DshToInitialize
        if ($r -eq '') {
            return ''
        }
    }

    $profiles = @(Get-ChildItem -LiteralPath $profilesDir -Directory -ErrorAction SilentlyContinue)
    if ($profiles.Count -eq 0) {
        $r = Start-DshToInitialize
        if ($r -eq '') {
            return ''
        }
        $profiles = @(Get-ChildItem -LiteralPath $profilesDir -Directory -ErrorAction SilentlyContinue)
    }

    if ($profiles.Count -eq 0) {
        Say-Err 'profile 目录还是空的'
        return ''
    }

    # 指定了名字就用指定的
    if ($ProfileName -ne '') {
        $hit = $profiles | Where-Object { $_.Name -eq $ProfileName }
        if ($null -eq $hit) {
            Say-Err ('找不到名为 ' + $ProfileName + ' 的 profile')
            Say-Info ('现有 profile：' + (($profiles | ForEach-Object { $_.Name }) -join ', '))
            return ''
        }
        return $hit.FullName
    }

    # 只有一个，直接用
    if ($profiles.Count -eq 1) {
        Say-Ok ('使用 profile：' + $profiles[0].Name)
        return $profiles[0].FullName
    }

    # 多个：优先 desktop，其次让用户选
    $desktop = $profiles | Where-Object { $_.Name -eq 'desktop' }
    if ($null -ne $desktop) {
        Say-Ok '使用 profile：desktop'
        return $desktop.FullName
    }

    Write-Host ''
    Say-Warn '检测到多个 profile，请选择要安装到哪一个：'
    for ($i = 0; $i -lt $profiles.Count; $i++) {
        Write-Host ('          [' + ($i + 1) + '] ' + $profiles[$i].Name) -ForegroundColor Gray
    }
    $sel = '1'
    if (-not $Unattended) {
        $sel = Read-Host '  输入序号'
    }
    $idx = 0
    if ([int]::TryParse($sel, [ref]$idx)) {
        if ($idx -ge 1 -and $idx -le $profiles.Count) {
            return $profiles[$idx - 1].FullName
        }
    }
    Say-Err '选择无效'
    return ''
}

# ================================================================
#  JSON 读写（必须无 BOM）
# ================================================================

function Read-JsonFile {
    param([string]$Path)
    $raw = [System.IO.File]::ReadAllText($Path, [System.Text.Encoding]::UTF8)
    # 万一有 BOM 也去掉，ConvertFrom-Json 不吃 BOM
    $raw = $raw.TrimStart([char]0xFEFF)
    return ($raw | ConvertFrom-Json)
}

function Write-JsonFile {
    param([string]$Path, $Object)

    $json = $Object | ConvertTo-Json -Depth 20
    # ★ 必须无 BOM —— 带 BOM 会让 Node 的 JSON.parse 抛异常
    $utf8NoBom = New-Object System.Text.UTF8Encoding $false
    [System.IO.File]::WriteAllText($Path, $json, $utf8NoBom)
}

function Test-Admin {
    <# 当前进程是否已经是管理员（app 包层要写 DSH 安装目录） #>
    try {
        $id = [Security.Principal.WindowsIdentity]::GetCurrent()
        $p = New-Object Security.Principal.WindowsPrincipal $id
        return $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    }
    catch {
        return $false
    }
}

function Reset-DuplicateEnvKeys {
    <#
        清掉「进程环境变量」里仅大小写不同的重复键。

        为什么需要：PS 5.1 的 Start-Process 会把当前 $env: 逐项塞进
        ProcessStartInfo.EnvironmentVariables（一个大小写不敏感的字典）。
        环境里若同时存在 Path 和 PATH，就会抛
          Item has already been added. Key in dictionary: 'Path' Key being added: 'PATH'
        本脚本要用 Start-Process 拉起 DSH 安装程序和 app-patch.ps1，
        不先扫干净就会以一句跟真实原因无关的报错中断。

        影响面：只改当前进程的环境副本，不碰注册表、不影响系统。
        做法：同组保留名字为 Path 的那个（Windows 规范写法），其余删掉。
    #>
    $all = [System.Environment]::GetEnvironmentVariables('Process')
    $groups = @($all.Keys | Group-Object { $_.ToLower() })
    $removed = 0

    foreach ($g in $groups) {
        if ($g.Count -le 1) { continue }
        $names = @($g.Group)

        $keep = @($names | Where-Object { $_ -ceq 'Path' } | Select-Object -First 1)
        if ($keep.Count -eq 0) { $keep = @($names[0]) }

        foreach ($n in $names) {
            if ($n -ceq $keep[0]) { continue }
            try {
                [System.Environment]::SetEnvironmentVariable($n, $null, 'Process')
                $removed++
            }
            catch {
                # 个别变量可能被系统保护，跳过即可
            }
        }
    }
    return $removed
}

function Quote-PsArg {
    <#
        Start-Process 的 -ArgumentList 只是把数组用空格拼成一条命令行，
        它不会替含空格的值加引号。所以像 D:\Program Files\DSH Desktop
        这样的路径会被拆成两个参数，报
          A positional parameter cannot be found that accepts argument 'Desktop'
        这里按 Windows 命令行规则手工加引号。
    #>
    param([string]$Value)

    if ($Value -eq '') { return '""' }
    if ($Value -notmatch '[\s"]') { return $Value }

    # 反斜杠紧邻引号时的转义规则（CommandLineToArgvW）
    $escaped = $Value -replace '(\\*)"', '$1$1\"'
    $escaped = $escaped -replace '(\\+)$', '$1$1'
    return '"' + $escaped + '"'
}

function Backup-File {
    param([string]$Path)

    if (-not (Test-Path -LiteralPath $Path)) {
        return ''
    }
    $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    $bak = ($Path + '.bak-jiufeng-' + $stamp)
    Copy-Item -LiteralPath $Path -Destination $bak -Force
    return $bak
}

function Copy-TreeReplacing {
    <#
        整目录替换式复制（幂等）。
        目标已存在时先删干净再复制，保证不会留下上一版的残留文件
        （插件/技能目录里残留的旧文件会让 DSH 加载到过期代码）。
    #>
    param(
        [string]$Source,
        [string]$Destination
    )

    if (Test-Path -LiteralPath $Destination) {
        Remove-Item -LiteralPath $Destination -Recurse -Force -ErrorAction Stop
    }
    $parent = Split-Path -Parent $Destination
    if (-not (Test-Path -LiteralPath $parent)) {
        New-Item -ItemType Directory -Path $parent -Force | Out-Null
    }
    Copy-Item -LiteralPath $Source -Destination $Destination -Recurse -Force
}

function Get-FileTextInfo {
    <#
        读文本文件，返回 @{ Text; Eol; HasBom }。
        保留原始换行符与 BOM 状态，避免"只想改一行却把整个文件重写"
        导致 DSH 或 Node 读不了。
    #>
    param([string]$Path)

    $raw = [System.IO.File]::ReadAllText($Path, [System.Text.Encoding]::UTF8)
    $hasBom = $raw.StartsWith([char]0xFEFF)
    if ($hasBom) { $raw = $raw.Substring(1) }

    $eol = "`n"
    if ($raw.Contains("`r`n")) { $eol = "`r`n" }

    return @{ Text = $raw; Eol = $eol; HasBom = $hasBom }
}

function Write-FileTextInfo {
    param(
        [string]$Path,
        [string]$Text,
        [bool]$HasBom
    )

    $enc = New-Object System.Text.UTF8Encoding $HasBom
    [System.IO.File]::WriteAllText($Path, $Text, $enc)
}

function Set-DefaultAgentPreset {
    <#
        把 settings.yaml 顶层的 agent-presets.default 设为指定值。

        为什么用正则文本处理而不是 YAML 解析：
        PS 5.1 没有内置 YAML，装第三方模块又会引入新依赖；
        而 settings.yaml 是 DSH 自己维护的 60 KB 大文件，
        用 ConvertFrom-Yaml 再写回会把格式和注释全部重排，风险更大。
        这里只做最小改动：定位 agent-presets 段，改写或补上 default 行。

        返回：'unchanged' | 'updated' | 'inserted' | 'appended'

        'unchanged' 时不写文件、也不备份 —— 让重复运行安装脚本保持干净。
        备份特意放在函数内部，就是为了「不改就不留垃圾备份」
        （settings.yaml 有 60 KB，跑几次就堆出几百 KB）。
    #>
    param(
        [string]$Path,
        [string]$PresetId
    )

    $info = Get-FileTextInfo -Path $Path
    $raw = $info.Text
    $eol = $info.Eol
    $result = ''

    # 顶层 agent-presets: 段（其后所有缩进行都算这一段）
    $m = [regex]::Match($raw, "(?m)^agent-presets:[ \t]*\r?\n((?:[ \t]+[^\r\n]*(?:\r?\n|$))*)")
    if ($m.Success) {
        $block = $m.Groups[1].Value
        if ([regex]::IsMatch($block, "(?m)^[ \t]+default:")) {
            # 已经是目标值就直接返回，不写不备份
            $same = '(?m)^[ \t]+default:[ \t]*' + [regex]::Escape($PresetId) + '[ \t]*$'
            if ([regex]::IsMatch($block, $same)) {
                return 'unchanged'
            }
            $newBlock = [regex]::Replace($block, "(?m)^([ \t]+)default:[^\r\n]*", ('${1}default: ' + $PresetId))
            $result = 'updated'
        }
        else {
            $newBlock = $block.TrimEnd() + $eol + '  default: ' + $PresetId + $eol
            $result = 'inserted'
        }
        $start = $m.Groups[1].Index
        $raw = $raw.Substring(0, $start) + $newBlock + $raw.Substring($start + $block.Length)
    }
    else {
        $raw = $raw.TrimEnd() + $eol + 'agent-presets:' + $eol + '  default: ' + $PresetId + $eol
        $result = 'appended'
    }

    # 确定要改了才备份
    $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    $bak = ($Path + '.bak-jiufeng-' + $stamp)
    Copy-Item -LiteralPath $Path -Destination $bak -Force
    Say-Info ('已备份原配置 -> ' + (Split-Path $bak -Leaf))

    Write-FileTextInfo -Path $Path -Text $raw -HasBom $info.HasBom
    return $result
}

function Merge-ProfilePatch {
    <#
        把「投研收窄」的禁用条目合并进 profile 的 cordis.patch.yml。

        为什么是合并而不是覆盖：这份文件是用户自己的 patch 层，
        粉丝可能已经往里加过别的东西，直接覆盖会抹掉他们的配置。
        按 id 判断是否已存在，只补缺的（连说明注释一起补）。

        为什么要带注释：作者本机那份就是带注释的，保持一致；
        粉丝也能看懂每条是干什么的、怎么恢复。

        返回：实际新增的条目数
    #>
    param(
        [string]$Path,
        [object[]]$Entries
    )

    $header = @(
        '# ⚠️ 关于「受控更新守卫」（禁用 DSH 自带更新入口）为什么不在本文件里：',
        '#',
        '# 本文件是 profile 层的用户 patch，层序上排在应用自带 overlays 之前',
        '# （见 dsh/lib/profile-boot-*.js 的 composeLive：',
        '#   [...bundlePatches, ...profilePatch, ...homePatch, ...overlays]）。',
        '# 而 desktop-updates 更新插件是由应用自带的 cordis.patch.yml 通过',
        '# loadOverlayPatches() 注入的（见 app/lib/profile-*.js），属于最后一层，',
        '# 会把本层的同 id 条目压掉。因此在本文件里写 disabled 不生效。',
        '#',
        '# 守卫的落点在对的那一层：',
        '#   <DSH 安装目录>\resources\app\cordis.patch.yml',
        '#     - id: desktop-updates',
        '#       name: dsh-plugin-desktop/updates',
        '#       disabled: true',
        '#',
        '# ── 投研收窄：停用与投研无关的 host 插件行 ──────────────────────',
        '#',
        '# 依据：本文件是 profile 层，层序上在 bundle 层（dsh-base / dsh-web-app）之后',
        '# 应用，因此**能**压掉这两个层里的行（与上面 desktop-updates 那类',
        '# overlays 层的行不同）。按 id 定位，最后写入者生效。',
        '#',
        '# 收益：少挂 6 个插件（内存 + 界面干净），token 收益≈0（这些行不是模型可见工具）。',
        '# 恢复方式：删掉下面对应那条即可。',
        '# 若要把整份还原，删掉本文件即可（DSH 会重新生成默认内容）。',
        '#',
        '# 刻意保留：session-log-download（/export 导出会话）· ui-deliverables（轮末产出文件行）',
        '#          · 全部 ui-session / ui-chat / ui-sidebar / ui-settings / workspace 行。'
    )

    if (Test-Path -LiteralPath $Path) {
        $info = Get-FileTextInfo -Path $Path
        $raw = $info.Text
        $eol = $info.Eol
        $hasBom = $info.HasBom
    }
    else {
        $raw = ($header -join "`n") + "`n"
        $eol = "`n"
        $hasBom = $false
    }

    $added = 0
    foreach ($e in $Entries) {
        $id = [string]$e.Id
        $pat = '(?m)^[ \t]*-[ \t]*id:[ \t]*' + [regex]::Escape($id) + '[ \t]*$'
        if ([regex]::IsMatch($raw, $pat)) {
            continue
        }

        # 注释与条目一起写，保证新增那条也带说明
        $chunk = ''
        foreach ($line in @($e.Note)) {
            $chunk += ('# ' + $line) + $eol
        }
        $chunk += '- id: ' + $id + $eol + '  disabled: true' + $eol

        $raw = $raw.TrimEnd() + $eol + $eol + $chunk
        $added++
    }

    if ($added -gt 0 -or -not (Test-Path -LiteralPath $Path)) {
        Write-FileTextInfo -Path $Path -Text $raw -HasBom $hasBom
    }
    return $added
}

# ================================================================
#  主流程
# ================================================================

Say-Banner

# 先清掉环境变量里仅大小写不同的重复键。
# 不清理的话，后面 Start-Process 会以一句跟真实原因毫无关系的报错中断，
# 详见 Reset-DuplicateEnvKeys 的注释。
$dupFixed = Reset-DuplicateEnvKeys
if ($dupFixed -gt 0) {
    Say-Info ('已清理 ' + $dupFixed + ' 个大小写重复的环境变量（只影响本次运行）')
}

# ---------- 1. 检查安装包完整性 ----------
Say-Step '检查安装包'

$root = Get-PackageRoot
$missing = Test-PackageComplete -Root $root
if ($missing.Count -gt 0) {
    Say-Err '安装包不完整，缺少这些内容：'
    foreach ($m in $missing) {
        Write-Host ('          - ' + $m) -ForegroundColor Red
    }
    Say-Info '请重新解压完整的压缩包再运行，不要只把 bat 文件单独拷出来。'
    Pause-Exit 1
}
Say-Ok ('安装包完整（' + $script:PluginNames.Count + ' 个插件）')

# ---------- 2. DSH ----------
Say-Step '检查 DSH Desktop'

$dshDir = Find-DshInstall
if ($dshDir -eq '') {
    Say-Warn '没有检测到 DSH Desktop，需要先安装它'

    $setup = Get-ChildItem -LiteralPath $root -Filter 'DSH-Desktop-*-Setup.exe' -ErrorAction SilentlyContinue |
        Sort-Object Name -Descending | Select-Object -First 1

    if ($null -eq $setup) {
        Say-Err '安装包里没有 DSH Desktop 安装程序'
        Say-Info '请到官方发布页下载安装 DSH Desktop 后，再重新运行本脚本：'
        Write-Host '          https://github.com/anywhere-labs/dsh-desktop/releases/latest' -ForegroundColor DarkCyan
        Pause-Exit 1
    }

    Say-Info ('使用安装包：' + $setup.Name)
    Say-Info '马上会弹出 DSH Desktop 的安装向导，按它的提示点下一步即可'
    if (-not $Unattended) {
        Write-Host ''
        $null = Read-Host '  按回车开始安装 DSH Desktop'
    }

    if ($DryRun) {
        Say-Info '[预演] 会运行 DSH Desktop 安装向导'
        $dshDir = '(预演)'
    }
    else {
        try {
            $proc = Start-Process -FilePath $setup.FullName -PassThru -Wait
        }
        catch {
            Say-Err ('安装程序启动失败：' + $_.Exception.Message)
            Pause-Exit 1
        }
        $dshDir = Find-DshInstall
        if ($dshDir -eq '') {
            Say-Err '安装似乎没有完成，没能检测到 DSH Desktop'
            Say-Info '可以手动装好之后再重新运行本脚本。'
            Pause-Exit 1
        }
    }
}
Say-Ok ('DSH Desktop 已就绪：' + $dshDir)

# ---------- 3. 关闭 DSH ----------
Say-Step '确认 DSH Desktop 已退出'

if ($DryRun) {
    Say-Info '[预演] 会检查并关闭正在运行的 DSH Desktop'
}
else {
    if (-not (Wait-DshClosed)) {
        Pause-Exit 1
    }
}

# ---------- 4. 定位 profile ----------
Say-Step '定位 DSH 配置目录'

$profileDir = ''
if ($DryRun) {
    $profilesDir = Join-Path (Get-DshHome) 'profiles'
    if (Test-Path -LiteralPath $profilesDir) {
        $profileDir = (Get-ChildItem -LiteralPath $profilesDir -Directory | Select-Object -First 1).FullName
        Say-Info ('[预演] 会写入：' + $profileDir)
    }
    else {
        Say-Info '[预演] profile 不存在，真实运行时会先启动 DSH 完成初始化'
        $profileDir = '(预演)'
    }
}
else {
    $profileDir = Resolve-ProfileDir
    if ($profileDir -eq '') {
        Pause-Exit 1
    }
}

# ---------- 5. 安装插件 ----------
Say-Step '安装插件'

$pluginStore = Join-Path (Get-DshHome) 'jiufeng-plugins'
Say-Info ('插件存放位置：' + $pluginStore)

if ($DryRun) {
    foreach ($n in $script:PluginNames) {
        Say-Info ('[预演] 复制 plugins\' + $n + ' -> ' + (Join-Path $pluginStore $n))
    }
    Say-Info '[预演] 改写 profile\package.json，挂上 node_modules 链接'
    Say-Info '[预演] 建立 node_modules junction 链接'
}
else {

# 下面 5.1 ~ 5.3 顶格书写是有意的：逻辑上它们都在上面这个「非预演」分支内
# （末尾有一个 } 闭合）。这样写只是为了让改动 diff 最小，不去重排上百行缩进。

# 5.1 复制插件到固定位置
if (-not (Test-Path -LiteralPath $pluginStore)) {
    New-Item -ItemType Directory -Path $pluginStore -Force | Out-Null
}

foreach ($n in $script:PluginNames) {
    $src = Join-Path (Join-Path $root 'plugins') $n
    $dst = Join-Path $pluginStore $n

    if (Test-Path -LiteralPath $dst) {
        # 已存在则整目录替换（先删干净的旧副本）
        try {
            Remove-Item -LiteralPath $dst -Recurse -Force -ErrorAction Stop
        }
        catch {
            Say-Err ('无法覆盖旧副本：' + $dst)
            Say-Info '可能是 DSH Desktop 还在运行，或该目录被别的程序占用。'
            Pause-Exit 1
        }
    }
    Copy-Item -LiteralPath $src -Destination $dst -Recurse -Force
    Say-Ok ('已安装 ' + $n)
}

# 5.2 改写 profile/package.json
$pkgPath = Join-Path $profileDir 'package.json'
if (-not (Test-Path -LiteralPath $pkgPath)) {
    Say-Err ('找不到 profile 的 package.json：' + $pkgPath)
    Pause-Exit 1
}

$pkg = Read-JsonFile -Path $pkgPath

# ── 先算期望状态，看是不是真的需要改 ──────────────────────────────
# 不改就不写：ConvertTo-Json 会把 DSH 自己维护的格式整份重排，
# 重复运行安装脚本时没必要动它，也省掉一个备份文件。
$curBundles = @()
if ($null -ne $pkg.dsh -and $null -ne $pkg.dsh.profile) {
    $curBundles = @($pkg.dsh.profile.bundles)
}

$needChange = $false
foreach ($n in $script:PluginNames) {
    $want = ('file:' + (Join-Path $pluginStore $n)).Replace('\', '/')
    $cur = ''
    if ($null -ne $pkg.dependencies) {
        $cur = [string]$pkg.dependencies.$n
    }
    if ($cur -ne $want) { $needChange = $true }
    if ($curBundles -notcontains $n) { $needChange = $true }
}

$bakPath = ''

if (-not $needChange) {
    Say-Ok 'profile 配置已是最新，无需改动'
}
else {
    $bakPath = Backup-File -Path $pkgPath
    if ($bakPath -ne '') {
        Say-Info ('已备份原配置 -> ' + (Split-Path $bakPath -Leaf))
    }

    # dependencies
    if ($null -eq $pkg.dependencies) {
        $pkg | Add-Member -NotePropertyName 'dependencies' -NotePropertyValue ([pscustomobject]@{}) -Force
    }
    $existingDeps = @($pkg.dependencies.PSObject.Properties | ForEach-Object { $_.Name })

    foreach ($n in $script:PluginNames) {
        $target = ('file:' + (Join-Path $pluginStore $n))
        $target = $target.Replace('\', '/')
        if ($existingDeps -contains $n) {
            $pkg.dependencies.$n = $target
        }
        else {
            $pkg.dependencies | Add-Member -NotePropertyName $n -NotePropertyValue $target -Force
        }
    }

    # dsh.profile.bundles
    if ($null -eq $pkg.dsh) {
        $pkg | Add-Member -NotePropertyName 'dsh' -NotePropertyValue ([pscustomobject]@{}) -Force
    }
    if ($null -eq $pkg.dsh.profile) {
        $pkg.dsh | Add-Member -NotePropertyName 'profile' -NotePropertyValue ([pscustomobject]@{}) -Force
    }
    if ($null -eq $pkg.dsh.profile.bundles) {
        $pkg.dsh.profile | Add-Member -NotePropertyName 'bundles' -NotePropertyValue @() -Force
    }

    $bundles = @($pkg.dsh.profile.bundles)
    foreach ($n in $script:PluginNames) {
        if ($bundles -notcontains $n) {
            $bundles += $n
        }
    }
    $pkg.dsh.profile.bundles = $bundles

    Write-JsonFile -Path $pkgPath -Object $pkg
    Say-Ok '已更新 profile 配置'
}

# 5.3 node_modules 下的链接
$nmDir = Join-Path $profileDir 'node_modules'
if (-not (Test-Path -LiteralPath $nmDir)) {
    New-Item -ItemType Directory -Path $nmDir -Force | Out-Null
}

foreach ($n in $script:PluginNames) {
    $link = Join-Path $nmDir $n
    $target = Join-Path $pluginStore $n

    if (Test-Path -LiteralPath $link) {
        try {
            Remove-Item -LiteralPath $link -Recurse -Force -ErrorAction Stop
        }
        catch {
            # 删不掉就跳过，下面会尝试直接建
        }
    }

    try {
        # ★ 用 junction：不需要开发者模式，也不需要管理员
        New-Item -ItemType Junction -Path $link -Target $target -ErrorAction Stop | Out-Null
        Say-Ok ('已链接 ' + $n)
    }
    catch {
        Say-Warn ('建立链接失败：' + $n)
        Say-Info ('错误：' + $_.Exception.Message)
        Say-Info '退而求其次，直接把插件复制进 node_modules'
        try {
            Copy-Item -LiteralPath $target -Destination $link -Recurse -Force -ErrorAction Stop
            Say-Ok ('已复制 ' + $n)
        }
        catch {
            Say-Err ('复制也失败了：' + $_.Exception.Message)
            Pause-Exit 1
        }
    }
}

}   # ← 结束第 5 步的「非预演」分支

# ---------- 6. 安装投研 Agent 预设 ----------
Say-Step '安装投研 Agent 预设'

$dshHome = Get-DshHome
$presetSrcDir = Join-Path (Join-Path $root 'agent-preset') $script:PresetDirName
$presetDstDir = Join-Path (Join-Path $dshHome '.agent-presets') $script:PresetDirName

if ($DryRun) {
    Say-Info ('[预演] ' + $presetSrcDir + '  ->  ' + $presetDstDir)
    Say-Info '[预演] 含 preset.yml + agent.cordis.yml + 89 个技能目录'
}
else {
    try {
        Copy-TreeReplacing -Source $presetSrcDir -Destination $presetDstDir
    }
    catch {
        Say-Err ('安装预设失败：' + $_.Exception.Message)
        Say-Info '如果提示目录被占用，先完全退出 DSH Desktop 再重跑本脚本。'
        Pause-Exit 1
    }
    $skillN = @(Get-ChildItem -LiteralPath (Join-Path $presetDstDir 'skills') -Directory).Count
    Say-Ok ('已安装投研预设：' + $skillN + ' 个技能')
    Say-Info ('位置：' + $presetDstDir)
}

# ---------- 7. 设为默认 Agent 预设 ----------
Say-Step '设为默认 Agent 预设'

$settingsPath = Join-Path $dshHome 'settings.yaml'

if ($DryRun) {
    Say-Info ('[预演] 把 ' + $settingsPath)
    Say-Info ('[预演] 顶层 agent-presets.default 设为 ' + $script:PresetId)
}
elseif (-not (Test-Path -LiteralPath $settingsPath)) {
    Say-Warn ('找不到 settings.yaml：' + $settingsPath)
    Say-Info 'DSH Desktop 第一次启动时才会生成它。'
    Say-Info '先启动一次 DSH，再重跑本脚本，这一步就会自动完成。'
}
else {
    try {
        # 备份由函数内部按需做：值已经对了就不写、不备份
        $how = Set-DefaultAgentPreset -Path $settingsPath -PresetId $script:PresetId
        if ($how -eq 'unchanged') {
            Say-Ok ('默认 Agent 预设已经是 ' + $script:PresetId + '，无需改动')
        }
        elseif ($how -eq 'updated') {
            Say-Ok ('已把默认 Agent 预设改为 ' + $script:PresetId)
        }
        elseif ($how -eq 'inserted') {
            Say-Ok ('已在 agent-presets 段补上 default: ' + $script:PresetId)
        }
        else {
            Say-Ok ('已新建 agent-presets 段并设为 ' + $script:PresetId)
        }
    }
    catch {
        Say-Err ('改写 settings.yaml 失败：' + $_.Exception.Message)
        Pause-Exit 1
    }
}

# ---------- 8. 铺品牌图标 ----------
Say-Step '铺品牌图标'

$iconsSrcDir = Join-Path $root 'icons'
$iconsDstDir = Join-Path $dshHome 'icons'

if ($DryRun) {
    Say-Info ('[预演] ' + $iconsSrcDir + '\*  ->  ' + $iconsDstDir)
    Say-Info ('[预演] 共 ' + $script:UserIconFiles.Count + ' 个图标文件')
}
elseif (-not (Test-Path -LiteralPath $iconsSrcDir)) {
    Say-Warn '包内没有 icons 目录，跳过这一步'
}
else {
    if (-not (Test-Path -LiteralPath $iconsDstDir)) {
        New-Item -ItemType Directory -Path $iconsDstDir -Force | Out-Null
    }
    $iconN = 0
    foreach ($f in $script:UserIconFiles) {
        $src = Join-Path $iconsSrcDir $f
        if (Test-Path -LiteralPath $src) {
            Copy-Item -LiteralPath $src -Destination (Join-Path $iconsDstDir $f) -Force
            $iconN++
        }
    }
    Say-Ok ('已铺 ' + $iconN + ' 个图标')
    Say-Info ('位置：' + $iconsDstDir)
}

# ---------- 9. 写 profile 层配置 ----------
Say-Step '写 profile 层配置'

$patchPath = Join-Path $profileDir 'cordis.patch.yml'

if ($DryRun) {
    Say-Info ('[预演] 往 ' + $patchPath)
    Say-Info ('[预演] 合并 ' + $script:SlimIds.Count + ' 条禁用项：' + ($script:SlimIds -join ', '))
}
else {
    try {
        $added = Merge-ProfilePatch -Path $patchPath -Entries $script:SlimEntries
    }
    catch {
        Say-Err ('写 cordis.patch.yml 失败：' + $_.Exception.Message)
        Pause-Exit 1
    }
    if ($added -gt 0) {
        Say-Ok ('已新增 ' + $added + ' 条（与投研无关的 host 插件）')
    }
    else {
        Say-Ok (([string]$script:SlimIds.Count) + ' 条禁用项已齐，无需改动')
    }
}

# ================================================================
#  app 包层：改 DSH 安装目录，需要管理员
# ================================================================
Write-Host ''
Write-Host ('  ── app 包层 ' + ('─' * 46)) -ForegroundColor Cyan
Write-Host ''

$patchScript = Join-Path $root 'app-patch.ps1'

if ($SkipApp) {
    Say-Warn '按参数要求跳过 app 包层'
    Say-Info '这一层负责：应用图标、品牌文案、受控更新守卫、prompt 收窄。'
    Say-Info '需要时以管理员身份单独运行包内的 app-patch.ps1。'
}
elseif (-not (Test-Path -LiteralPath $patchScript)) {
    Say-Warn '包内没有 app-patch.ps1，跳过 app 包层'
}
else {
    # 用 PowerShell 自身的绝对路径，避免粉丝机器 PATH 里没有 powershell.exe
    $psExe = Join-Path $PSHOME 'powershell.exe'
    if (-not (Test-Path -LiteralPath $psExe)) {
        $psExe = 'powershell.exe'
    }

    $psArgs = @(
        '-NoProfile',
        '-ExecutionPolicy', 'Bypass',
        '-File', (Quote-PsArg $patchScript),
        '-PackageRoot', (Quote-PsArg $root)
    )
    if ($DryRun) { $psArgs += '-DryRun' }
    if ($dshDir -ne '' -and $dshDir -ne '(预演)') {
        # 顺手兼容粉丝把 DSH 装在 D:\Program Files 这类带空格的路径
        $psArgs += @('-AppRoot', (Quote-PsArg $dshDir))
    }

    $proc = $null

    if ((Test-Admin) -or $DryRun) {
        # 共用当前控制台：收尾由 install.ps1 统一负责，所以让子脚本不要暂停
        # （否则会出现两次「按回车键关闭此窗口」）。
        $sharedArgs = $psArgs + '-Unattended'
        Write-Host '  正在应用……' -ForegroundColor Gray
        Write-Host ''
        $proc = Start-Process -FilePath $psExe -ArgumentList $sharedArgs -Wait -PassThru -NoNewWindow
    }
    else {
        # 另开提权窗口：子脚本自己暂停，粉丝才看得见结果。
        $elevatedArgs = $psArgs
        if ($Unattended) { $elevatedArgs += '-Unattended' }
        Write-Host '  这一步要写入 DSH 的安装目录，马上会弹出一次「用户账户控制」。' -ForegroundColor Yellow
        Write-Host '  点「是」放行，会另开一个窗口显示进度，跑完按回车关闭它即可。' -ForegroundColor Yellow
        Write-Host ''
        try {
            # ★ 用 RunAs 让系统自己弹 UAC：粉丝只需点一次「是」，
            #   不需要自己去找「以管理员身份运行」。
            #   注意 RunAs 不能和 -NoNewWindow 同时用。
            $proc = Start-Process -FilePath $psExe -ArgumentList $elevatedArgs -Verb RunAs -Wait -PassThru
        }
        catch {
            $proc = $null
        }
    }

    if ($null -eq $proc) {
        Say-Warn '提权被取消，app 包层没有应用'
        Say-Info '图标与品牌文案仍是 DSH 默认样式，功能不受影响。'
        Say-Info '补做方法：右键「以管理员身份运行」本目录里的 install.bat。'
    }
    else {
        $rc = $proc.ExitCode
        if ($rc -eq 0) {
            Say-Ok 'app 包层完成（图标 / 品牌文案 / 更新守卫 / prompt 收窄）'
        }
        elseif ($rc -eq 3) {
            Say-Warn 'app 包层仍缺管理员权限，这一步没有完成'
            Say-Info '补做方法：右键「以管理员身份运行」本目录里的 install.bat。'
        }
        else {
            Say-Warn ('app 包层返回码 ' + $rc + '，可能没有完整应用')
            Say-Info '可以运行 app-patch.ps1 -Verify 查看当前状态。'
        }
    }
}

# ---------- 完成 ----------
if ($DryRun) {
    Write-Host ''
    Write-Host '  预演结束，没有改动任何文件。' -ForegroundColor Yellow
    Pause-Exit 0
}

Write-Host ''
Write-Host '  ============================================' -ForegroundColor Green
Write-Host '       安装完成' -ForegroundColor Green
Write-Host '  ============================================' -ForegroundColor Green
Write-Host ''
Write-Host '  现在打开（或重启）DSH Desktop，左侧栏就会变成投研工作台。' -ForegroundColor White
Write-Host ''
Write-Host '  会看到：' -ForegroundColor Gray
Write-Host '    · 投研工作流  —— 7 个分析师工作流' -ForegroundColor Gray
Write-Host '    · 专业工具    —— 101 个专业技能，7 个分类' -ForegroundColor Gray
Write-Host '    · 历史对话' -ForegroundColor Gray
Write-Host ''
Write-Host '  这次一共装好了四层，与作者本机环境一致：' -ForegroundColor White
Write-Host '    [1] 侧边栏界面     投研工作台 UI' -ForegroundColor Gray
Write-Host '    [2] 21 个金融数据工具  对话里自动可用，不用配置' -ForegroundColor Gray
Write-Host '    [3] 投研 Agent 预设    89 个技能（含多空辩论）' -ForegroundColor Gray
Write-Host '    [4] 应用外观       图标 / 品牌文案 / 受控更新守卫' -ForegroundColor Gray
Write-Host ''
Write-Host '  ★ 还需要你自己做一件事：配置模型' -ForegroundColor Yellow
Write-Host '    模型额度是作者个人的，不能分发。请打开 DSH Desktop 的设置，' -ForegroundColor Gray
Write-Host '    填上你自己的 API Key（DeepSeek / 通义 / 智谱 等）即可使用。' -ForegroundColor Gray
Write-Host '    不配也能打开界面，但对话会报错。' -ForegroundColor DarkGray
Write-Host ''
Write-Host ('  想卸载：删掉 ' + $pluginStore + '，') -ForegroundColor DarkGray
if ($bakPath -ne '') {
    Write-Host ('          再把 ' + (Join-Path $profileDir 'package.json') + ' 恢复成 ' + (Split-Path $bakPath -Leaf)) -ForegroundColor DarkGray
}
else {
    Write-Host ('          再到 ' + (Join-Path $profileDir 'package.json') + ' 里删掉那两个依赖') -ForegroundColor DarkGray
}
Write-Host ''

Pause-Exit 0
